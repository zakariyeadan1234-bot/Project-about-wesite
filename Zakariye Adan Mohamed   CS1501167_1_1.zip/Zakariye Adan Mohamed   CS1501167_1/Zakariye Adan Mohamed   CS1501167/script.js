// 1. CSS Styles
const style = document.createElement('style');
style.textContent = `
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;600;800&display=swap');
    :root { --bg: #0b0f1a; --card: #161b2a; --accent: #fbbf24; --text: #f8fafc; --secondary: #94a3b8; --glass: rgba(255, 255, 255, 0.03); }
    body { font-family: 'Plus Jakarta Sans', sans-serif; 
    margin: 0;
     background: var(--bg); 
     color: var(--text); 
     line-height: 1.6; 
     scroll-behavior: smooth; }
    header { background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%); 
    padding: 60px 20px; 
    text-align: center; border-bottom: 1px solid rgba(251, 191, 36, 0.2); }
    header h1 { margin: 0; font-size: 2.8rem; font-weight: 800; background: linear-gradient(to right, #fbbf24, #f59e0b); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
    nav { background: rgba(11, 15, 26, 0.8); backdrop-filter: blur(12px); padding: 15px; display: flex; justify-content: center; gap: 15px; position: sticky; top: 0; z-index: 1000; border-bottom: 1px solid var(--glass); }
    nav a { color: var(--secondary); text-decoration: none; font-weight: 600; cursor: pointer; padding: 10px 20px; border-radius: 12px; transition: 0.4s; }
    nav a:hover { background: var(--glass); color: var(--accent); transform: translateY(-2px); }
    main { max-width: 900px; margin: 40px auto; padding: 20px; }
    .kaadh { background: var(--card); padding: 35px; border-radius: 24px; box-shadow: 0 20px 40px rgba(0,0,0,0.3); margin-bottom: 40px; border: 1px solid var(--glass); position: relative; }
    .badge-tirada { background: rgba(251, 191, 36, 0.1); color: var(--accent); padding: 6px 16px; border-radius: 12px; font-size: 13px; font-weight: 700; float: right; border: 1px solid rgba(251, 191, 36, 0.2); }
    pre { background: #010409; color: #e6edf3; padding: 20px; border-radius: 16px; overflow-x: auto; font-size: 14px; position: relative; margin: 20px 0; border: 1px solid #30363d; white-space: pre-wrap; }
    .run-btn { background: var(--accent); color: #000; border: none; padding: 6px 14px; border-radius: 8px; cursor: pointer; font-weight: 800; font-size: 11px; transition: 0.3s; text-transform: uppercase; }
    .run-btn:hover { background: #fff; transform: scale(1.05); }
    .profile-img { width: 180px; height: 180px; border-radius: 40px; object-fit: cover; border: 4px solid var(--card); outline: 2px solid var(--accent); margin-bottom: 25px; }
    .About-item { margin: 12px 0; font-size: 17px; padding: 15px; background: var(--glass); border-radius: 12px; text-align: left; }
    .About-item a { color: var(--accent); font-weight: bold; text-decoration: none; }
    .about-links a { display: inline-block; color: var(--text); font-weight: bold; text-decoration: none; background: var(--glass); padding: 12px 20px; border-radius: 12px; margin: 8px; border: 1px solid rgba(255,255,255,0.1); transition: 0.3s; }
    .about-links a:hover { border-color: var(--accent); color: var(--accent); }
    footer { padding: 40px; text-align: center; color: var(--secondary); font-size: 14px; border-top: 1px solid var(--glass); }
    
    /* Contact Form Styles */
    .contact-form input, .contact-form textarea {
        width: 100%; padding: 12px; margin: 10px 0; border-radius: 8px; border: 1px solid var(--glass);
        background: rgba(255,255,255,0.05); color: white; outline: none; box-sizing: border-box;
    }
    .submit-btn {
        background: var(--accent); color: black; border: none; padding: 12px 25px; border-radius: 8px;
        cursor: pointer; font-weight: bold; width: 100%; transition: 0.3s;
    }
    .submit-btn:hover { background: white; }
`;
document.head.appendChild(style);

// 2. Data Structure
const chapterData = [
    {
        title: "Chapter 7: Objects & Classes",
        count: 17,
        examples: [
            "// 1. Literal Object\nconst user = {name:'Zakariye', age:22};\nalert(user.name);",
            "// 2. Bracket Notation\nconst car = {brand:'PRADA'};\nalert(car['brand']);",
            "// 3. Add Property\nconst dev = {}; dev.lang = 'JS';\nalert(dev.lang);",
            "// 4. Nested Object\nconst s = {info: {id: 1167}};\nalert(s.info.id);",
            "// 5. Delete Property\nconst obj = {x:10, y:20}; delete obj.x;\nalert('x' in obj);",
            "// 6. Object.keys()\nconst data = {a:1, b:2};\nalert(Object.keys(data));",
            "// 7. Object.values()\nconst data = {a:1, b:2};\nalert(Object.values(data));",
            "// 8. Constructor Function\nfunction User(n){this.n=n;}\nconst u = new User('Ali');\nalert(u.n);",
            "// 9. Method inside Object\nconst o = {hi:()=>'Hello'};\nalert(o.hi());",
            "// 10. For..in Loop\nconst p = {a:1, b:2};\nfor(let k in p) console.log(k);\nalert('Check Console');",
            "// 11. Class Syntax\nclass Person { constructor(n){this.n=n;} }\nconst p = new Person('Zak');\nalert(p.n);",
            "// 12. Class Inheritance\nclass A { talk(){return 'hi';} }\nclass B extends A {}\nconst b = new B(); alert(b.talk());",
            "// 13. JSON Stringify\nconst obj = {id:1};\nalert(JSON.stringify(obj));",
            "// 14. JSON Parse\nconst str = '{\"id\":2}';\nalert(JSON.parse(str).id);",
            "// 15. Object.assign\nconst o1={a:1}, o2={b:2};\nObject.assign(o1, o2);\nalert(o1.b);",
            "// 16. Static Method\nclass M { static add(a,b){return a+b;} }\nalert(M.add(5,5));",
            "// 17. Shorthand Property\nconst name='Zak';\nconst u = {name};\nalert(u.name);"
        ]
    },
    {
        title: "Chapter 8: DOM Manipulation",
        count: 20,
        examples: [
            "// 1. Get Element\nconst h = document.querySelector('h1');\nh.style.color = '#fbbf24'; alert('Header color changed');",
            "// 2. Create Element\nconst p = document.createElement('p');\np.innerText = 'New paragraph added!'; document.body.appendChild(p);",
            "// 3. InnerHTML Update\ndocument.querySelector('footer p').innerHTML = 'Updated: <b>2025 JS Project</b>';",
            "// 4. Set Attribute\nconst nav = document.querySelector('nav');\nnav.setAttribute('data-mode', 'dark'); alert('Attribute set');",
            "// 5. Hide Element\nconst h = document.querySelector('header h1');\nh.style.opacity='0.5'; alert('Header faded');",
            "// 6. Change Background\ndocument.body.style.backgroundColor = '#0f172a';",
            "// 7. Add CSS Class\ndocument.body.classList.add('custom-theme'); alert('Class added');",
            "// 8. Toggle Class\ndocument.body.classList.toggle('dark-mode'); alert('Toggled');",
            "// 9. QuerySelectorAll\nconst links = document.querySelectorAll('nav a');\nalert('Total links: ' + links.length);",
            "// 10. Parent Element\nconst btn = document.querySelector('.run-btn');\nalert('Parent tag: ' + btn.parentElement.tagName);",
            "// 11. Access Child Nodes\nconst nav = document.querySelector('nav');\nalert('First child: ' + nav.children[0].textContent);",
            "// 12. TextContent\nconst footer = document.querySelector('footer p');\nalert('Current footer: ' + footer.textContent);",
            "// 13. Element Border\ndocument.querySelector('.kaadh').style.border = '2px solid gold';",
            "// 14. Append Image\nconst img = document.createElement('img');\nimg.src = 'https://via.placeholder.com/40'; document.body.prepend(img);",
            "// 15. Get Attribute\nconst val = document.querySelector('nav a').getAttribute('onclick');\nalert('Value: ' + val);",
            "// 16. Remove Element\nconst temp = document.createElement('div');\ntemp.id='tmp'; document.body.appendChild(temp);\ndocument.getElementById('tmp').remove(); alert('Removed temp div');",
            "// 17. Class List Remove\ndocument.body.classList.remove('active'); alert('Class removed');",
            "// 18. Check Class\nconst hasClass = document.body.classList.contains('main');\nalert('Has class: ' + hasClass);",
            "// 19. InnerText vs Content\nconst head = document.querySelector('h1');\nalert('Text: ' + head.innerText);",
            "// 20. Closest Element\nconst btn = document.querySelector('.run-btn');\nconst card = btn.closest('.kaadh');\ncard.style.boxShadow = '0 0 20px #fbbf24';"
        ]
    },
    {
        title: "Chapter 9: Events",
        count: 25,
        examples: [
            "// 1. OnClick\ndocument.onclick = () => console.log('Page Clicked'); alert('Global click active');",
            "// 2. OnKeyDown\ndocument.onkeydown = (e) => alert('Key pressed: ' + e.key);",
            "// 3. OnMouseOver\nconst h1 = document.querySelector('h1');\nh1.onmouseover = () => h1.style.letterSpacing = '5px';",
            "// 4. OnMouseOut\nh1.onmouseout = () => h1.style.letterSpacing = 'normal';",
            "// 5. OnResize\nwindow.onresize = () => console.log('Resizing window...');",
            "// 6. OnLoad\nwindow.onload = () => alert('Window Loaded');",
            "// 7. OnContextMenu\nwindow.oncontextmenu = (e) => { e.preventDefault(); alert('Right click blocked'); };",
            "// 8. OnCopy\ndocument.oncopy = () => alert('Text copied!');",
            "// 9. OnFocus\nconst input = document.createElement('input');\ninput.placeholder = 'Focus me';\ninput.onfocus = () => input.style.background = 'gold';\ndocument.body.prepend(input);",
            "// 10. OnBlur\ninput.onblur = () => input.style.background = '#fff';",
            "// 11. AddEventListener\ndocument.addEventListener('dblclick', () => alert('Double Click!'));",
            "// 12. RemoveEventListener\nconst greet = () => alert('Hi');\ndocument.addEventListener('click', greet);\ndocument.removeEventListener('click', greet); alert('Listener Removed');",
            "// 13. Event Target\ndocument.body.onclick = (e) => alert('Target: ' + e.target.tagName);",
            "// 14. Stop Propagation\ndocument.querySelector('.run-btn').onclick = (e) => { e.stopPropagation(); alert('Only this btn'); };",
            "// 15. Prevent Default\nconst link = document.createElement('a'); link.href='https://google.com';\nlink.onclick = (e) => { e.preventDefault(); alert('Link stopped'); };\ndocument.body.appendChild(link);",
            "// 16. OnMouseEnter\nconst card = document.querySelector('.kaadh');\ncard.onmouseenter = () => card.style.transform = 'scale(1.02)';",
            "// 17. OnMouseLeave\ncard.onmouseleave = () => card.style.transform = 'scale(1)';",
            "// 18. OnInput\ninput.oninput = (e) => console.log('Typing...');",
            "// 19. OnChange\ninput.onchange = () => alert('Changed');",
            "// 20. OnScroll\nwindow.onscroll = () => console.log('Scrolling...');",
            "// 21. Mouse Position\ndocument.onmousemove = (e) => window.status = e.clientX;",
            "// 22. Keyboard Code\ndocument.onkeyup = (e) => alert('Code: ' + e.code);",
            "// 23. OnPaste\ninput.onpaste = () => alert('Text Pasted');",
            "// 24. Drag Start\ndocument.ondragstart = () => alert('Dragging...');",
            "// 25. Custom Event\nconst ev = new Event('hi');\ndocument.addEventListener('hi', () => alert('Custom Hi!'));\ndocument.dispatchEvent(ev);"
        ]
    }
];

// 3. Logic Functions
function initApp() {
    document.body.innerHTML = "";
    const h = document.createElement("header");
    h.innerHTML = "<h1>Javascript Assignments</h1><p style='color:var(--secondary); margin-top:10px;'> Computer Science And IT</p>";
    document.body.appendChild(h);

    const n = document.createElement("nav");
    [{ n: "HOME", i: "home" }, { n: "CHAPTERS", i: "chapters" }, { n: "ABOUT", i: "about" }, { n: "CONTACT", i: "contact" }].forEach(m => {
        const a = document.createElement("a"); a.textContent = m.n; a.onclick = () => loadPage(m.i); n.appendChild(a);
    });
    document.body.appendChild(n);

    const mainArea = document.createElement("main");
    mainArea.id = "main-content";
    document.body.appendChild(mainArea);

    const f = document.createElement("footer");
    f.innerHTML = "<p>© 2026 Zakariye Adan Mohamed.</p>";
    document.body.appendChild(f);

    loadPage("home");
}

function loadPage(page) {
    const mainArea = document.getElementById("main-content");
    mainArea.innerHTML = "";
    if (page === "home") {
        mainArea.innerHTML = `<div class="kaadh" style="text-align:center; padding: 80px 20px;"><h1 style="font-size: 3rem; color: var(--accent);">Welcome to My Web Page</h1><p style="font-size: 1.2rem; color: var(--secondary);">Exploration of JavaScript Chapters</p></div>`;
    }
    else if (page === "chapters") {
        chapterData.forEach(ch => {
            const div = document.createElement("div"); div.className = "kaadh";
            div.innerHTML = `<span class="badge-tirada">${ch.count} EXAMPLES</span><h2>${ch.title}</h2><hr style="border:0; border-top:1px solid var(--glass); margin:20px 0;">`;
            ch.examples.forEach(ex => {
                const pre = document.createElement("pre");
                pre.textContent = ex;
                const btn = document.createElement("button");
                btn.className = "run-btn";
                btn.style.position = "absolute"; btn.style.top = "15px"; btn.style.right = "15px";
                btn.textContent = "Run ▶";
                btn.onclick = () => { try { eval(ex); } catch (e) { alert("Error: " + e); } };
                pre.appendChild(btn); div.appendChild(pre);
            });
            mainArea.appendChild(div);
        });
    }
    else if (page === "about") {
        mainArea.innerHTML = `
        <div class="kaadh" style="text-align: center;">
            <img src="y.jpg" class="profile-img" onerror="this.src='https://scontent.fmgq1-2.fna.fbcdn.net/v/t39.30808-6/477184243_1151260509712812_6947765647478064229_n.jpg?_nc_cat=101&ccb=1-7&_nc_sid=a5f93a&_nc_ohc=NAbGEMFZkTQQ7kNvwFZwggm&_nc_oc=AdnnUPn0SUIVJfenKwYZeHcuY-g2OHgHPN1_1nRU_83iNJ3KdyqPMI1hRw0-h_tfj-w&_nc_zt=23&_nc_ht=scontent.fmgq1-2.fna&_nc_gid=RGTRSflq45eo7vWP8NAE-g&oh=00_AfkJoyUYtrE0SVANXjBaNK4OBqYYykMuRsTJxr0O12_n4Q&oe=69594CC6'">
            <div class="About-item"> <a>Name:</a> Zakariye Adan Mohamed</div>
            <div class="About-item">🆔 <a>ID Card:</a> CS1501167</div>
            <div class="About-item">📧 <a>Email:</a> zakariye@gmail.com</div>
            <div class="About-item">📧 <a>Batch:</a> Batch15</div>
            <div class="About-item">📧 <a>Class:</a> B</div>
            <div class="About-item">📞 <a>Phone:</a> +252 619793072</div>
            <div class="About-item">🎓 <a>Jaamacad:</a> Jazeera University</div>
            <div class="About-item">💻 <a>Skills:</a> Graphic Designer</div>
            <div class="about-links">
                <a href="file:///C:/Users/zakar/OneDrive/Desktop/project%20about%20website/index.html#contact" target="_blank">🔗 AKMEL ONLINE</a>
                <a href="https://www.salaambank.so/" target="_blank">🔗 Salaam bank</a>
            </div>
        </div>`;
    }
    else if (page === "contact") {
        mainArea.innerHTML = `
        <div class="kaadh">
            <h2 style="color: var(--accent);">Contact Me</h2>
            <p style="color: var(--secondary);">Send me a message and I will get back to you.</p>
            <div class="contact-form">
                <input type="text" id="name" placeholder="Full Name">
                <input type="email" id="email" placeholder="Your Email">
                <textarea id="message" rows="5" placeholder="Your Message"></textarea>
                <button class="submit-btn" onclick="sendMessage()">Send Message</button>
            </div>
        </div>`;
    }
}

// Function to handle contact message
function sendMessage() {
    const name = document.getElementById('name').value;
    const msg = document.getElementById('message').value;
    if(name && msg) {
        alert("Mahadsanid " + name + "! Fariintaada waa la diray.");
        loadPage("home");
    } else {
        alert("Fadlan buuxi magaca iyo fariinta.");
    }
}

// Start
initApp();